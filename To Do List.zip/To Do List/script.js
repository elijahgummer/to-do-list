$(document).ready(function () {
    $('.icon').click(function () {
        $('.field').toggleClass("hide");
        $('.icon').toggleClass("rotate");
    });

    $('.add-btn').click(function () {
        var task = $('input').val();
        if (task.trim() !== '') {
            $('.tasks').append("<li class='task'><span><i class='fas fa-trash'></i></span>" + task + "</li>");
            $('input').val('');
        }
    });

    $('.tasks').on("click", 'span', function () {
        $(this).parent().fadeOut(300, function () {
            $(this).remove();
        });
    });
});
